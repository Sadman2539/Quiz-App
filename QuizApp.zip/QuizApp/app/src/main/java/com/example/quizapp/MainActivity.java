package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //Declaring variables
    Button mTrueButton, mFalseButton, mNextButton, mPrevButton;
    int mIndex;
    int mQuestion;
    TextView mQuestionTextView;

//  Question Array
    private Question[] mQuestions=  {
            new Question(R.string.question_1,true),
            new Question(R.string.question_2,false),
            new Question(R.string.question_3,true),
            new Question(R.string.question_4,true),
            new Question(R.string.question_5,true)
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //FindViewByID
        mTrueButton = findViewById(R.id.trueButtonID);
        mFalseButton = findViewById(R.id.false_buttonID);
        mPrevButton = findViewById(R.id.prev_button);
        mNextButton = findViewById(R.id.next_button);
        mQuestionTextView =findViewById(R.id.questionTextViewID);

        
        mQuestion = mQuestions[mIndex].getQuestionID();
        mQuestionTextView.setText(mQuestion);


        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(true);
            }
        });

        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(false);
            }
        });

        mPrevButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backwardUpdateQuestion();
            }
        });

        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                forwardUpdateQuestion();
            }
        });
    }

    private void forwardUpdateQuestion(){
        mIndex = (mIndex + 1) % mQuestions.length;
        mQuestion = mQuestions[mIndex].getQuestionID();
        mQuestionTextView.setText(mQuestion);
    }

    private void backwardUpdateQuestion(){
        mIndex = (mIndex - 1+mQuestions.length) % mQuestions.length;
        mQuestion = mQuestions[mIndex].getQuestionID();
        mQuestionTextView.setText(mQuestion);
    }
    private  void checkAnswer(boolean userSelection){
        if (userSelection == mQuestions[mIndex].isAnswer()){
            Toast.makeText(MainActivity.this, R.string.correct_toast, Toast.LENGTH_SHORT).show();

        }
        else{
            Toast.makeText(this, R.string.incorrect_toast, Toast.LENGTH_SHORT).show();
        }

    }
}
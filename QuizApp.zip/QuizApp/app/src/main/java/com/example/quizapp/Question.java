package com.example.quizapp;

public class Question {
    private int mQuestionID;
    private boolean mAnswer;

    public int getQuestionID() {
        return mQuestionID;
    }

    public void setQuestionID(int questionID) {
        mQuestionID = questionID;
    }

    public boolean isAnswer() {
        return mAnswer;
    }

    public void setAnswer(boolean answer) {
        mAnswer = answer;
    }

    public Question(int questionResourceID, boolean answer){
        mQuestionID = questionResourceID;
        mAnswer = answer;

    }
}
